function clickBtn(){
    var e=document.getElementById('aa');
    e.innerHTML="Hello!!"
}